package Project;

public class AsciiValue {
	public static void main(String[] String)   
	{  
	int ch1 = 'A';  
	int ch2 = 'd';  
	System.out.println("The ASCII value of A is: "+ch1);  
	System.out.println("The ASCII value of d is: "+ch2);  
	}  
}
