package Project;

public class Square {
	public static void main(String[] args) {
		int s=5;
		int area=s*s;
		System.out.println("Area of the square:"+area);
	}

}
