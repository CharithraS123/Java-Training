package Project;
import java.util.Scanner;
public class Transaction {
		int accountNumber;
		double balance=30000;
		Scanner sc=new Scanner(System.in);
		int getAccountNumber() {
			System.out.println("enter account number");
			accountNumber=sc.nextInt();
			return accountNumber;
		}
		void execute() {
			
			System.out.println("account balance is"+balance);
		}
		public static void main(String a[]) {
			Transaction t=new Transaction();
			System.out.println("account number is :"+t.getAccountNumber());
			t.execute();
			BalanceInquiry bq=new BalanceInquiry();
			bq.execute();
			Withdrawal wd=new Withdrawal();
			wd.execute();
			Deposit dp = new Deposit();
			dp.execute();
			
			
		}
	}

	class BalanceInquiry extends Transaction{
		void execute() {
			
			System.out.println("account balance is"+balance);
		}
	}
	class Deposit extends Transaction{
		public double amount;
		void execute() {
			System.out.println("enter the amount todeposit");
			amount=sc.nextDouble();
			balance=balance+amount;
			System.out.println("account balance is"+balance);
		}
	}

	class Withdrawal extends Transaction{
		double amount;
		void execute() {
			System.out.println("enter the amount to withdraw");
			amount=sc.nextDouble();
			balance=balance-amount;
			System.out.println("account balance is"+balance);
		}
	}


