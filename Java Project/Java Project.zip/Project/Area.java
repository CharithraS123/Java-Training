package Project;

public class Area {
  /*void circle(int r) {
	 double res=3.14*r*r;
	 System.out.println("area of circle "+r+"is"+res);
 }
 void rectangle(int l, int w) {
	 double area=l*w;
	 System.out.println("area of rectangle "+l+""+w+"is"+area);
 }
  void square(int n) {
	 int res=n*n;
	 System.out.println("area of square "+n+"is"+res);
 }
 public static void main(String[] args) {
	 Area a=new Area();
	a.circle(4);
	a.rectangle(3,6);
	a.square(5);
	
} */
	    double circle(int r) {
		 double res=3.14*r*r;
		 System.out.println("area of circle "+r+"is"+res);
		 return res;
		 
	 }
	  double rectangle(int l, int w) {
		 double area=l*w;
		 System.out.println("area of rectangle "+l+""+w+"is"+area);
		 return area;
	 }
	  int square(int n) {
		 int res=n*n;
		 System.out.println("area of square "+n+"is"+res);
		 return res;
	 }
	 public static void main(String[] args) {
		 Area a=new Area();
		a.circle(4);
		a.rectangle(3,6);
		a.square(5);
	
}
}
