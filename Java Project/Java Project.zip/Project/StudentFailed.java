package Project;

	class StudentFailed extends Exception
	{
	 
	    public StudentFailed (String message) {
	        super(message);

	    }
	   
	}
	class NegativeNumber extends Exception
	{
	 
	    public NegativeNumber (String message) {
	    super(message);

	    }
	    
	}
	class PasswordgLengthNotMatch extends Exception
	{
	 
	    public PasswordgLengthNotMatch (String message) {
	    super(message);

	    }
	    
	}
	class NotEven extends Exception
	{
	 
	    public NotEven (String message) {
	    super(message);

	    }
	    
	}

