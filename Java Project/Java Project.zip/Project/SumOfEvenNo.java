package Project;
import java.util.Scanner;
public class SumOfEvenNo {
	public static void main(String[] args) {
		
	      Scanner in= new Scanner(System.in);
		    
			System.out.print("Enter the value of n: ");
			int n = in.nextInt();
			
			int sum= n*(n+1);
			
			System.out.println("Sum: "+sum);
			

		}
}
