package Project;
import java.util.*;

public class MainClass {
	public static void main(String[] args, int numPassenger) {
	Scanner sc= new Scanner(System.in);	
      System.out.println("Type of Car:");
      System.out.println("1 Scorpio");
      System.out.println("2 Audi");
      int c=sc.nextInt();
      if(c==1) {
    	  Scorpio s= new Scorpio();
    	  System.out.println("Your Tune up Cost will be"+s.tuneUpCost());
    	  System.out.println("Enter the number of people");
    	  int n=sc.nextInt();
    
		if(s.canCarry(numPassenger)==true) {
    		  System.out.println("You can accomodate "+n+" people in your car");
    	  }
    	  else {
    		  System.out.println("You can not accomodate "+n+" people in your car");
    	  }
      }
      
      Audi a= new Audi();
	  System.out.println("Your Tune up Cost will be"+a.tuneUpCost());
	  System.out.println("Enter the number of people");
	  int n=sc.nextInt();

	if(a.canCarry(numPassenger)==true) {
		  System.out.println("You can accomodate "+n+" people in your car");
	  }
	  else {
		  System.out.println("You can not accomodate "+n+" people in your car");
	  }
  }
	}


