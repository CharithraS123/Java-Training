package Project;

public class SumOfTwo {
    void add (float a,float b) {
	  float sum = a + b;
	  System.out.println("sum of two no is:"+sum);
  }
  public static void main(String[] args) {
	  SumOfTwo s=new SumOfTwo();
	s.add(34.5f,665.76f);
	
}
}
