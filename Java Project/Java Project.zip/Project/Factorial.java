package Project;
import java.util.Scanner;
public class Factorial {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a number to find Factorial");
	int num=sc.nextInt();
	Factorial f=new Factorial();
	f.fact(num);
	

	}
	 void fact(int num) {
		 int i,f=1;
			for(i=1;i<=num;i++) {
				f=f*i;
			}
			System.out.println("Factorial of the "+num+" is +f");
		
	}
}
