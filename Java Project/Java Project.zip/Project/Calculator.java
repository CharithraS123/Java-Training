package Project;
import java.util.Scanner;
public class Calculator {

	public static void main(String aa[])
    {
        char choice;
        Scanner scan=new Scanner(System.in);  //2
        do {
        System.out.println("Enter first no"); //3
        int ch1= scan.nextInt();  //4
        System.out.println("Enter second no");
        int ch2= scan.nextInt(); 
        System.out.println("Select your operation :\n1.Addition\n2.Sub\n3.Mul\n4.Div");
        int op=scan.nextInt();
        if(op==1)
        {
            System.out.println("Addition :"+(ch1+ch2));
        }
        else if(op==2)
        {
            System.out.println("Subtraction :"+(ch1-ch2));
        }
        else if(op==3)
        {
            System.out.println("Mul :"+(ch1*ch2));
        }
        else if(op==4)
        {
            System.out.println("Division :"+(ch1/ch2));
        }else
        {
 
            System.out.println("Enter valid choice(1,2,3,4)");
        }
        System.out.println("Do you want to continue?(y/n)");
        choice=scan.next().charAt(0);
        }
        while(choice=='y' || choice=='Y');
        System.out.println("Thankyou!!!");
}
}

