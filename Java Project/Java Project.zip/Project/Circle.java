package Project;

public class Circle {
	public static void main(String[] args) {
		int radius=5;
		double pi=3.142,area;
		area=pi*radius*radius;
		System.out.println("Area of Circle is:"+area);

	}
}
