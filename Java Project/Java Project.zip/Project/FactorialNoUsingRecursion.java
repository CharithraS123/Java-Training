package Project;

public class FactorialNoUsingRecursion {
	public static void main(String[] args) {
        int num = 6;
        long factorial = mulNum(num);
        System.out.println("Factorial of " + num + " = " + factorial);
    }
    public static long mulNum(int num)
    {
        if (num >= 1)
            return num * mulNum(num - 1);
        else
            return 1;
    }
}
