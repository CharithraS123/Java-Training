package Project;

public class Audi implements Vehicle
{

	@Override
	public double tuneUpCost() {
		double t=31000;
		return t;
	}

	@Override
	public boolean canCarry(int numPassenger) {
		if(numPassenger<=5) {
		return true;
	}
	else {
		return false;
	}

}
}
