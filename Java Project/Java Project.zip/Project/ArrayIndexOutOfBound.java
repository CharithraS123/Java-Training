package Project;

public class ArrayIndexOutOfBound {
	public static void main(String args[])
	   {
	      try{
	        int a[]= {10,20,30,40};
	        System.out.println(a[100]);
	      }
	      catch(ArrayIndexOutOfBoundsException e){
	         System.out.println ("ArrayIndexOutOfBounds");
	      }
	   }
}
