package Project;

public class Rectangle {
	public static void main(String[] args) {
		int length=5;
		int breadth=10;
		int area=length*breadth;
		System.out.println("Area of rectangle:"+area);
	}
}
