package Project;

public class Constructor {
		
		 public static void main(String aa[])
		    {
			 car cr= new car("kia", 5000000);
			 cr.displayDetails();
			 Area a1=new Area();
			 Area a2=new Area();
			 Area a3=new Area();
			 Area a4=new Area();
		    }  
	}


	    class car{
		String brandName;
		int price;
		car(String brdN, int pr ){
			this.brandName=brdN;
			this.price=pr;
		}
		void displayDetails() {
			  
			System.out.println(brandName+" "+price);
		}
	}

