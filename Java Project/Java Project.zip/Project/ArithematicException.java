package Project;

public class ArithematicException {
	public static void main(String args[])
	   {
	      try{
	         int n1=30, n2=0;
	         int output= n1/n2;
	         System.out.println ("Result: "+output);
	      }
	      catch(ArithmeticException e){
	         System.out.println ("Do not divide a number by zero");
	      }
	   }
}
