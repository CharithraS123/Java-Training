package Project;


	abstract class Animal{

		
		   class cat extends Animal{
			   
			  }
			public void main(String[] args) {
				Animal obj=new cat();
				obj.makeSound();
		
			}
		 

		public void makeSound() {
			 System.out.println("Meow!!!");
			
		}
}

