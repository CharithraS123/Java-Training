package Project;

public interface Vehicle {
   public double tuneUpCost();
   public boolean canCarry(int numPassenger);
}

