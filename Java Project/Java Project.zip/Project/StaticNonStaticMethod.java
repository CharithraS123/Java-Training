package Project;

public class StaticNonStaticMethod {
	static int i=3;
	int a=5;
	int changeValue() {
		i++;
		a++;
		System.out.println("value of i is"+i);
		System.out.println("value of a is"+a);
		return 1;
	}
	public static void main(String[] args) {
		StaticNonStaticMethod p=new StaticNonStaticMethod();
		System.out.println("value of i is"+i);
		
		p.changeValue();
		System.out.println("value of i is"+i);
		System.out.println("value of a is"+p.a);
		StaticNonStaticMethod p2=new StaticNonStaticMethod();
		System.out.println("value is"+p2.i);
		System.out.println("value  of a is "+p2.a);
		StaticNonStaticMethod p3=new StaticNonStaticMethod();
		System.out.println("value is"+p3.i);
		System.out.println("value of a  is"+p3.a);
	}
}
