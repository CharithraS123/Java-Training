package Project;

public class GradeOfStudent {
	public static void main(String[] args) {
		
	      String grade = null;
	      
	      switch(2) {
	      
	        case 1:grade = "A";
	           break;
	        
	        case 2:grade = "B";
	           break;
	      
	        case 3: grade = "C";
	           break;
	        
	        case 4: grade = "D";
	           break;
	        
	        case 5:  grade = "E";
	            break;
	       
	         default: grade = "F";
	            break;
	       }
	       
	       System.out.println("Grade = " + grade);
	}
}
