package Project;

public class Table {

	public static void main(String[] args) {
		int num=3;
		int i=1;
		do {
			System.out.println(num*i);
			i++;
		}
		while(i<=10);

	}

}
