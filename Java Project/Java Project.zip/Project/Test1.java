package Project;

public class Test1 {
	public static void main(String[] args) {
		System.out.println("My Details------");
		System.out.println("My Name is_Charithra___");
		System.out.println("I am learning java technology");
		System.out.println("My age is 23");

		}
}
