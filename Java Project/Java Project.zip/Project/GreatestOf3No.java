package Project;

public class GreatestOf3No {
	public static void main(String[] args) {
		int a=50, b=84,c=20;
		if(a>=b && a>=c)
			System.out.println(a+"is the greatest Number");
		else if(b>=a && b>=c)
			System.out.println(b+"is the greatest Number");
		else
			System.out.println(c+"is the greatest Number");
	}
}
