package Project;

public class Test {
     int i=2;
     
}
