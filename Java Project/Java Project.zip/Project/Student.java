package Project;
import java.util.Scanner;
public class Student {
		public static void main(String args[]) {
			Scanner sc=new Scanner(System.in);
			System.out.println("enter the marks");
	        int marks = sc.nextInt();
	        try{
	         if(marks<200)
	         {
	             throw new StudentFailed("marks less than 200 failed exception");
	         }
	         else {
	        	 System.out.println("student marks is: "+marks);
	         }
	        }
	        catch(StudentFailed e)
	        {
	               System.out.println(e); 
	        }
	        System.out.println("\n");
	        
	        System.out.println("enter the number");
	        int num = sc.nextInt();
	        try{
	         if(num<0)
	         {
	             throw new NegativeNumber("number is less than 0, negative exception");
	         }
	         else {
	        	 System.out.println("number is: "+num);
	         }
	        }
	        catch(NegativeNumber ex)
	        {
	               System.out.println(ex); 
	        }
	        System.out.println("\n");
	        
	        System.out.println("enter the string");
	        String str = sc.next();
	        try{
	         if(str.length()<10)
	         {
	             throw new PasswordgLengthNotMatch("string length is less than 10, password lentgh not grater than 10 exception");
	         }
	         else {
	        	 System.out.println("string is: "+str);
	         }
	        }
	        catch(PasswordgLengthNotMatch ex)
	        {
	               System.out.println(ex); 
	        }
	        System.out.println("\n");
	        
	        System.out.println("enter the number");
	        int num1 = sc.nextInt();
	        try{
	         if(num1%2!=0)
	         {
	             throw new NotEven("number is not divisible by 2, not even exception");
	         }
	         else {
	        	 System.out.println("number is: "+num1);
	         }
	        }
	        catch(NotEven ex)
	        {
	               System.out.println(ex); 
	        }
	    }
	}

