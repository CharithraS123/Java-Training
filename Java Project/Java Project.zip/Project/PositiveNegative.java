package Project;

public class PositiveNegative {
	public static void main(String[] args) {
		int num=102;
		if(num>0)
		{
			System.out.println(num+ "is a Positive number");
		}
		else if(num<0)
		{
			System.out.println(num+ "is a Negative number");
		}
		else
		{
			System.out.println(num+ "is a neither Positive nor Negative number");
		}
		}
}
