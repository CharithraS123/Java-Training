package Project;

public class Scorpio implements Vehicle {

	@Override
	public double tuneUpCost() {
		double t=15000;
		return 0;
	}

	@Override
	public boolean canCarry(int numPassenger) {
		if(numPassenger<=7) {
		return true;
	}else
	{
	return false;	
	}
}
}
