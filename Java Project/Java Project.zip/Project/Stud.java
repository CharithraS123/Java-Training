package Project;

public class Stud {
		 public static void main(String aa[])
		    {
		     Employee e=new Employee("12","35000");
		     System.out.print(e.Details());
		}

		}

		class Employee
		{
		    String id,salary;

		        Employee(String x,String  sal)
		        {
		            id=x;
		            salary=sal;
		        }    

		    String Details()
		    {
		        return id+" "+salary;
		    }
}
