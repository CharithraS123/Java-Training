package Project;

public class NullPointer {
	public static void main (String[] args)
    {
        String p = null;
        try
        {

            if (p.equals("chari"))
                System.out.print("Same");
            else 
                System.out.print("Not Same");
        }
        catch(NullPointerException e)
        {
            System.out.print("NullPointerException Caught");
        }
    }
}
