package Project;

public class GreatestOf4No {
	public static void main(String[] args) {
		int a=50, b=84,c=20,d=50;
		if(a>=b && a>=c && a>=d)
			System.out.println(a+"is the greatest Number");
		else if(b>=a && b>=c && b>=d)
			System.out.println(b+"is the greatest Number");
		else if(c>=a && c>=b && c>=d)
			System.out.println(c+"is the greatest Number");
		else
			System.out.println(d+"is the greatest Number");
	}
}
